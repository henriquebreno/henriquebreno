using FluentValidation;

public class ValorCreditoMenorValorRenegociacaoBoletoRuleValidator : AbstractValidator<Contrato>
{
    public ValorCreditoMenorValorRenegociacaoBoletoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
