using FluentValidation;

public class ValorCreditoMenorValorRenegociacaoDebitoContaRuleValidator : AbstractValidator<Contrato>
{
    public ValorCreditoMenorValorRenegociacaoDebitoContaRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
