using FluentValidation;

public class ClientePossuiContratoDeAntecipacaoDeBeneficioFechamentoNaoLocalizadoRuleValidator : AbstractValidator<Contrato>
{
    public ClientePossuiContratoDeAntecipacaoDeBeneficioFechamentoNaoLocalizadoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
