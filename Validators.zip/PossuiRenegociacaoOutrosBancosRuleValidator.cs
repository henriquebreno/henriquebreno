using FluentValidation;

public class PossuiRenegociacaoOutrosBancosRuleValidator : AbstractValidator<Contrato>
{
    public PossuiRenegociacaoOutrosBancosRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
