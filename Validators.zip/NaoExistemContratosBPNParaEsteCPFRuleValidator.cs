using FluentValidation;

public class NaoExistemContratosBPNParaEsteCPFRuleValidator : AbstractValidator<Contrato>
{
    public NaoExistemContratosBPNParaEsteCPFRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
