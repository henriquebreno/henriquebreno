using FluentValidation;

public class ContratoSemParcelasAptasParaCobrancaRuleValidator : AbstractValidator<Contrato>
{
    public ContratoSemParcelasAptasParaCobrancaRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
