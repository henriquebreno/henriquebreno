using FluentValidation;

public class NaoExistemEnvioDebitosParaEsteCPFRuleValidator : AbstractValidator<Contrato>
{
    public NaoExistemEnvioDebitosParaEsteCPFRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
