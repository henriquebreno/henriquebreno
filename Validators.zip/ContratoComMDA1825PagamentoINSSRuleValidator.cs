using FluentValidation;

public class ContratoComMDA1825PagamentoINSSRuleValidator : AbstractValidator<Contrato>
{
    public ContratoComMDA1825PagamentoINSSRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
