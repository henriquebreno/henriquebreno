using FluentValidation;

public class ContratoDesconsideradoPelaTabelaFracionamentolRuleValidator : AbstractValidator<Contrato>
{
    public ContratoDesconsideradoPelaTabelaFracionamentolRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
