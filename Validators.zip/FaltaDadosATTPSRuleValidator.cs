using FluentValidation;

public class FaltaDadosATTPSRuleValidator : AbstractValidator<Contrato>
{
    public FaltaDadosATTPSRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
