using FluentValidation;

public class NaoExistemContratosAtivosNaBaseParaEsseCPFRuleValidator : AbstractValidator<Contrato>
{
    public NaoExistemContratosAtivosNaBaseParaEsseCPFRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
