using FluentValidation;

public class ContratoNaoPossuiAgendaComAlteracaoPVRuleValidator : AbstractValidator<Contrato>
{
    public ContratoNaoPossuiAgendaComAlteracaoPVRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
