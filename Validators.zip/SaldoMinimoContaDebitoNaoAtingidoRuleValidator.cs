using FluentValidation;

public class SaldoMinimoContaDebitoNaoAtingidoRuleValidator : AbstractValidator<Contrato>
{
    public SaldoMinimoContaDebitoNaoAtingidoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
