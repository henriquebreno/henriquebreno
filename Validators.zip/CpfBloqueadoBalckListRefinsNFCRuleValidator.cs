using FluentValidation;

public class CpfBloqueadoBalckListRefinsNFCRuleValidator : AbstractValidator<Contrato>
{
    public CpfBloqueadoBalckListRefinsNFCRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
