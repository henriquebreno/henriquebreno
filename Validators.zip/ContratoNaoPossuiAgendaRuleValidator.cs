using FluentValidation;

public class ContratoNaoPossuiAgendaRuleValidator : AbstractValidator<Contrato>
{
    public ContratoNaoPossuiAgendaRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
