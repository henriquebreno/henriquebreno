using FluentValidation;

public class ContratoValorCreditoInferiorAoPmtRuleValidator : AbstractValidator<Contrato>
{
    public ContratoValorCreditoInferiorAoPmtRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
