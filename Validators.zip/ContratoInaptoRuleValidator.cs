using FluentValidation;

public class ContratoInaptoRuleValidator : AbstractValidator<Contrato>
{
    public ContratoInaptoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
