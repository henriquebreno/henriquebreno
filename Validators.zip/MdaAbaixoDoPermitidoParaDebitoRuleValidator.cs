using FluentValidation;

public class MdaAbaixoDoPermitidoParaDebitoRuleValidator : AbstractValidator<Contrato>
{
    public MdaAbaixoDoPermitidoParaDebitoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
