using FluentValidation;

public class ContratoNaoPossuiSaldoMinimoParaFechamentoRuleValidator : AbstractValidator<Contrato>
{
    public ContratoNaoPossuiSaldoMinimoParaFechamentoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
