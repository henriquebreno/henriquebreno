using FluentValidation;

public class ErroProcessamentoRuleValidator : AbstractValidator<Contrato>
{
    public ErroProcessamentoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
