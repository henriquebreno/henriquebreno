using FluentValidation;

public class PossuiBloqueioJudicialRuleValidator : AbstractValidator<Contrato>
{
    public PossuiBloqueioJudicialRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
