using FluentValidation;

public class TransferenciaBeneficioINSSRuleValidator : AbstractValidator<Contrato>
{
    public TransferenciaBeneficioINSSRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
