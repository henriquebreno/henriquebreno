using FluentValidation;

public class ContratoPossuiAcordoRenegociacaoJudicialRuleValidator : AbstractValidator<Contrato>
{
    public ContratoPossuiAcordoRenegociacaoJudicialRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
