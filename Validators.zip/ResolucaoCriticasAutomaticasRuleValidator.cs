using FluentValidation;

public class ResolucaoCriticasAutomaticasRuleValidator : AbstractValidator<Contrato>
{
    public ResolucaoCriticasAutomaticasRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
