using FluentValidation;

public class PendenteBaixaRuleValidator : AbstractValidator<Contrato>
{
    public PendenteBaixaRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
