using FluentValidation;

public class ContratoPossuiBloqueioDebitoRuleValidator : AbstractValidator<Contrato>
{
    public ContratoPossuiBloqueioDebitoRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
