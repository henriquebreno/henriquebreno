using FluentValidation;

public class ClientePossuiContratoDeAntecipacaoDeBeneficioRuleValidator : AbstractValidator<Contrato>
{
    public ClientePossuiContratoDeAntecipacaoDeBeneficioRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
