using FluentValidation;

public class NaoExistemContratosParametrizadosParaCobrancaRuleValidator : AbstractValidator<Contrato>
{
    public NaoExistemContratosParametrizadosParaCobrancaRuleValidator()
    {
        RuleFor(c => c.Numero)
            .NotEmpty()
            .WithMessage("Número do contrato não pode ser vazio.");
    }
}
