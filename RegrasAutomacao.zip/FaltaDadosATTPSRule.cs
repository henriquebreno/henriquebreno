public class FaltaDadosATTPSRule : RegraBase
{
    public override TipoContrato TipoCompatibilidade => TipoContrato.Ambos;
    public override int Ordem => 20;
    public override ExecutarRegraResponse? ExecutarRegra(Contrato contrato, RegraContexto contexto) => null; // TODO
}
