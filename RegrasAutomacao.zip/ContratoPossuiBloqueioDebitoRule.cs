public class ContratoPossuiBloqueioDebitoRule : RegraBase
{
    public override TipoContrato TipoCompatibilidade => TipoContrato.Ambos;
    public override int Ordem => 6;
    public override ExecutarRegraResponse? ExecutarRegra(Contrato contrato, RegraContexto contexto) => null; // TODO
}
