public class SaldoMinimoContaDebitoNaoAtingidoRule : RegraBase
{
    public override TipoContrato TipoCompatibilidade => TipoContrato.Ambos;
    public override int Ordem => 1;
    public override ExecutarRegraResponse? ExecutarRegra(Contrato contrato, RegraContexto contexto) => null; // TODO
}
