public class NaoExistemEnvioDebitosParaEsteCPFRule : RegraBase
{
    public override TipoContrato TipoCompatibilidade => TipoContrato.Ambos;
    public override int Ordem => 23;
    public override ExecutarRegraResponse? ExecutarRegra(Contrato contrato, RegraContexto contexto) => null; // TODO
}
