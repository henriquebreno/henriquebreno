public class PossuiRenegociacaoOutrosBancosRule : RegraBase
{
    public override TipoContrato TipoCompatibilidade => TipoContrato.Ambos;
    public override int Ordem => 26;
    public override ExecutarRegraResponse? ExecutarRegra(Contrato contrato, RegraContexto contexto) => null; // TODO
}
